# add.rb
# input: natural number a, b
# output: a + b

a = gets().to_i
b = gets().to_i
ans = a
while b > 0
  ans = ans + 1
  b = b - 1
end
puts(ans)
