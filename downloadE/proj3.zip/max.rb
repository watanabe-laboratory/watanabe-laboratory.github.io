# max.rb
# input: a sequence of numbers
# output: max. number and its index

a = gets().split.map(&:to_i)
n = a.length
max = -10000
maxj = -1
for j in 0..(n-1)

end
puts(max, maxj)
