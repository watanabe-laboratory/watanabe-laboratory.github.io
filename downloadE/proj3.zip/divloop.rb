# divloop.rb
# input: d
# output: 1/d

puts("Input denominator d")
d = gets().to_i
print("Find 1 / ", d, "\n")
#t = Array.new(d, 0)

x = 1
stop = 0
while stop != 1
  x = x * 10
  q = x / d
  x = x % d
  print(q, ", ", x, "\n");  sleep(0.5)
  if x == 0
    stop = 1
  end
end
