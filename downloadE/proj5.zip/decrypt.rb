# decrypt.rb
# input: cipher text by Caesar cipher (k shift)
# output: plain text

def dec(k, c)
   # prepare
   code_a = 97
   leng = c.length

   # compute plaintext
   a = c.unpack("C*")

   b = Array.new(leng)
   for  i in 0..(leng-1)
      dist = a[i] - code_a
      if 0 <= dist && dist <= 25
         b[i] = code_a # the code computed from a[i] shifted by -k
      else
         b[i] = a[i]
      end
   end

   m = b.pack("C*") 
   return m
end

k = 7
ciphertext = gets.chomp
plaintext = dec(k, ciphertext)
puts(plaintext)
