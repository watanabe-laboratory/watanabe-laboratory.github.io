# hukugo.rb
# input: angobun (Caesar ango (k shift))
# output: hirabun (= moto no bun)

#===== koko ha kansuu (subroutine tomo iu) no teigi =====
def dec(k, c)
   code_a = 97
   nagasa = c.length

   a = c.unpack("C*")

   b = Array.new(nagasa)
   for  i in 0..(nagasa-1)
      sa = a[i] - code_a
      if 0 <= sa && sa <= 25
         b[i] = code_a + ((sa - k)%26)   # korede -k shift ga dekiru
      else
         b[i] = a[i]
      end
   end

   m = b.pack("C*") 
   return m
end
#===== kokokara program hontai =====
angobun = gets.chomp
hirabun = dec(0, angobun)
puts(hirabun)
