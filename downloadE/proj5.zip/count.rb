# count.rb
# input: a string (= ciphertext)
# output: the number of occurrences of each char.

code_a = 97
ciphertext = gets.chomp
leng = ciphertext.length
aa = ciphertext.unpack("C*")
freq = Array.new(26, 0)

for  i  in 0..(leng-1)
   dist = aa[i] - code_a

   print(ciphertext[i], ", ", aa[i], ", ", dist, "\n")
   
end 

print(freq, "\n")