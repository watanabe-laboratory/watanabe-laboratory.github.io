# encrypt.rb
# input: plain text
# output: cipher text by Caesar cipher (k shift)

def enc(k, m)


end

k = 7
plaintext = gets.chomp
ciphertext = enc(k, plaintext)
puts(ciphertext)

