# mult.rb
# input: natural number x, y
# output: x * y

x = gets().to_i
y = gets().to_i
ans = 0
while y > 0
  ans = ans + x
  y = y - 1
end
puts(ans)
