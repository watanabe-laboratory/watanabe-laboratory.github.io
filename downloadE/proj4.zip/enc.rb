# enc.rb
# input: string m
# output: encripted m by Caesar cipher (k shift)

# prepare
code_a = 97
k = 3
m = gets.chomp
leng = m.length

# compute ciphertext
a = m.unpack("C*")

b = Array.new(leng)
for  i in 0..(leng-1)
   dist = a[i] - code_a

   print(m[i], ", ", a[i], ", ", dist, "\n")

   if 0 <= dist && dist <= 25
      b[i] = code_a # the code computed from a[i] shifted by +k
   else
      b[i] = a[i]
   end
end

c = b.pack("C*") 
puts(c)                       
