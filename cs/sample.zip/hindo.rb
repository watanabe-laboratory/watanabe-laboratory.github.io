# hindo.rb
# input: mojiretsu (tatoeba, angobun)
# output: kaku moji (small English letter) no hindo

code_a = 97
mojiretsu = gets.chomp
nagasa = mojiretsu.length
code_retsu = mojiretsu.unpack("C*")
hindo = Array.new(26, 0)

for  i  in 0..(nagasa-1)
   sa = code_retsu[i] - code_a
   #print(mojiretsu[i], ", ", code_retsu[i], ", ", sa, "\n")
   if 0 <= sa && sa <= 25
      hindo[sa] = hindo[sa] + 1
      #print(hindo, "\n")
   end
end
print(hindo, "\n")

max = -1
max_sa = -1
for sa in 0..25
  if hindo[sa] > max
    max = hindo[sa]
    max_sa = sa
  end
end
print("max = ", max, " <-- sono ichi (moji a karano sa) = ", max_sa, "\n")