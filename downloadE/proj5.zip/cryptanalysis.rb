# cryptanalysis.rb
# input: cipher text by Caesar cipher (k shift), where k is unknown
# output: plain text

def dec(k, c)
   # prepare
   code_a = 97
   leng = c.length

   # compute plaintext
   a = c.unpack("C*")

   b = Array.new(leng)
   for  i in 0..(leng-1)
      dist = a[i] - code_a
      if 0 <= dist && dist <= 25
         b[i] = code_a + ((dist - k)%26) # the code computed from a[i] shifted by -k
      else
         b[i] = a[i]
      end
   end

   m = b.pack("C*") 
   return m
end

code_a = 97
ciphertext = gets.chomp

# compute k


# decrypt with the obtained ke
plaintext = dec(k, ciphertext)
puts(plaintext)
