# ango.rb
# input: hirabun (= moto no bun)
# output: angobun (Caesar ango (k shift))

#===== koko ha kansuu (subroutine tomo iu) no teigi =====
def enc(k, m)
   code_a = 97
   nagasa = m.length

   a = m.unpack("C*")

   b = Array.new(nagasa)
   for  i in 0..(nagasa-1)
      sa = a[i] - code_a
      if 0 <= sa && sa <= 25
         b[i] = code_a + ((sa + k)%26)  # korede +k shift wo shietiru
      else
         b[i] = a[i]
      end
   end

   c = b.pack("C*")
   return c
end

#===== kokokara program hontai =====
hirabun = gets.chomp
angobun = enc(0, hirabun)
puts(angobun)

