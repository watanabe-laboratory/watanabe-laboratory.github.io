# max.rb
# output: max value and its index in freq

freq = [0,0,1,2,0,5,8,1,2,5,0,3,3,0,1,8,3,2,3,1,0,0,1,2,1,0]

print(freq, "\n")

max = -1
max_dist = -1

for dist in 0..25
  if freq[dist] > max
    max = freq[dist]
    max_dist = dist
    print(max, ",", max_dist, "\n")
  end
end

print(max, ",", max_dist, "\n")
