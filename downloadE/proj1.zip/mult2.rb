# mult2.rb (multiplication by basic comp. only)
# iput: natural number x, y
# output: x * y

x = gets().to_i
y = gets().to_i
ans = 0
while y > 0

  a = ans
  b = x
  add_ans = a
  while b > 0
    add_ans = add_ans + 1
    b = b - 1
  end

  ans = add_ans
  y = y - 1
end        
puts(ans) 
