# abcPrint.rb
# input: string ss
# output: large case alphabet letters in ss

code_a = 97
puts("Give me a string")
ss = gets().chomp
leng = ss.length
aa = ss.unpack("C*")

for  i in 0..(leng-1)
  
   puts(ss[i])

end
